#!/usr/bin/env bash
# Simple local test server for static files (works for testing on your device)
# Usage: chmod +x deploy.sh && ./deploy.sh
PORT=8080
echo "Serving this folder on http://localhost:${PORT}"
python3 -m http.server ${PORT}
