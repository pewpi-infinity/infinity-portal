// _worker.js — PewPi Minimal (no Durable Object required)
// Deploy via Cloudflare Pages (Direct Upload). No bindings. Secrets optional:
//   OPENAI_API_KEY  (for /ask-openai)
//   IBM_API_KEY     (for /ask-watsonx)

const json = (o, s=200) => new Response(JSON.stringify(o), {status:s, headers:{"Content-Type":"application/json"}});

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);

    // WebSocket endpoint (single-connection echo; no broadcast without DO)
    if (url.pathname === "/ws") {
      if (req.headers.get("Upgrade") !== "websocket") return new Response("Expected WebSocket", { status: 426 });
      const pair = new WebSocketPair();
      const [client, server] = Object.values(pair);
      server.accept();
      server.send("👋 connected (minimal echo mode)");
      server.addEventListener("message", (evt)=>{
        const msg = String(evt.data||"").slice(0,2000);
        try { server.send("you: " + msg); } catch {}
      });
      return new Response(null, { status: 101, webSocket: client });
    }

    // OpenAI ask (optional)
    if (url.pathname === "/ask-openai" && req.method === "POST") {
      if (!env.OPENAI_API_KEY) return json({ error: "OPENAI_API_KEY not set" }, 500);
      const { prompt, system, model="gpt-4o-mini", temperature=0.7 } = await req.json();
      if (!prompt) return json({ error: "Missing prompt" }, 400);
      const body = { model, messages:[...(system?[{role:"system",content:system}]:[]), {role:"user",content:prompt}], temperature };
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method:"POST",
        headers:{ "Authorization":`Bearer ${env.OPENAI_API_KEY}`, "Content-Type":"application/json" },
        body: JSON.stringify(body)
      });
      const text = await r.text();
      return new Response(text, { status:r.status, headers:{ "Content-Type": r.headers.get("Content-Type") || "application/json" }});
    }

    // Watsonx ask (optional)
    if (url.pathname === "/ask-watsonx" && req.method === "POST") {
      if (!env.IBM_API_KEY) return json({ error: "IBM_API_KEY not set" }, 500);
      const { prompt, system, max_new_tokens=256 } = await req.json();
      if (!prompt) return json({ error: "Missing prompt" }, 400);
      // Token
      const form = new URLSearchParams();
      form.set("grant_type","urn:ibm:params:oauth:grant-type:apikey");
      form.set("apikey", env.IBM_API_KEY);
      const tok = await fetch("https://iam.cloud.ibm.com/identity/token", {
        method: "POST", headers:{ "Content-Type":"application/x-www-form-urlencoded" }, body: form
      });
      if (!tok.ok) return json({ error:"IBM IAM failed", status: tok.status }, 502);
      const { access_token } = await tok.json();
      // Inference
      const region = env.WX_REGION || "us-south";
      const model = env.WX_MODEL_ID || "ibm/granite-13b-chat-v2";
      const base  = env.WX_URL || `https://${region}.ml.cloud.ibm.com/ml/v1/text/generation`;
      const input = system ? `${system}\n\nUser: ${prompt}` : prompt;
      const payload = { input, parameters:{ decoding_method:"greedy", max_new_tokens }, model_id:model, project_id: env.WX_PROJECT || undefined };
      const r = await fetch(base, {
        method:"POST", headers:{ "Authorization":`Bearer ${access_token}`, "Content-Type":"application/json" }, body: JSON.stringify(payload)
      });
      const text = await r.text();
      return new Response(text, { status:r.status, headers:{ "Content-Type": r.headers.get("Content-Type") || "application/json" }});
    }

    // UI
    if (url.pathname === "/") {
      return new Response(`<!doctype html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PewPi Minimal</title>
<style>
  body{font:16px system-ui;margin:20px;background:#0b0d10;color:#e6e9ef}
  #log{border:1px solid #2a2f3a;background:#0f1319;height:54vh;overflow:auto;padding:10px;border-radius:12px}
  #row{display:flex;gap:8px;margin-top:12px}
  input,button{font:inherit}
  input{flex:1;padding:10px;border-radius:10px;border:1px solid #2a2f3a;background:#0f1319;color:#e6e9ef}
  button{padding:10px 14px;border-radius:10px;border:1px solid #2a2f3a;background:#18202a;color:#e6e9ef;cursor:pointer}
</style></head>
<body>
<h2>⚡ PewPi Minimal (no bindings)</h2>
<div id="log"></div>
<div id="row">
  <input id="msg" placeholder="Type message…"/>
  <button id="send">Send</button>
  <button id="askO">Ask OpenAI</button>
  <button id="askW">Ask Watson</button>
</div>
<script>
const log = document.getElementById('log');
function add(html){ log.insertAdjacentHTML('beforeend', html); log.scrollTop = log.scrollHeight; }
function esc(s){return s.replace(/[&<>"]/g,m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[m]))}
const proto = location.protocol==="https:"?"wss:":"ws:";
const ws = new WebSocket(proto+"//"+location.host+"/ws");
ws.onopen = ()=>add('<div>🔌 connected (echo)</div>');
ws.onmessage = e=>add('<div>'+esc(e.data)+'</div>');
document.getElementById('send').onclick=()=>{ const v=document.getElementById('msg').value.trim(); if(!v) return; ws.send(v); document.getElementById('msg').value=""; };
document.getElementById('askO').onclick=async ()=>{
  const v=document.getElementById('msg').value.trim(); if(!v) return;
  add('<div>🧠 OpenAI…</div>');
  const r=await fetch("/ask-openai",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:v})});
  const t=await r.text(); try{ const j=JSON.parse(t); add('<div>AI(OpenAI): '+esc(j.choices?.[0]?.message?.content||t)+'</div>'); }catch{ add('<div>AI(OpenAI): '+esc(t)+'</div>'); }
};
document.getElementById('askW').onclick=async ()=>{
  const v=document.getElementById('msg').value.trim(); if(!v) return;
  add('<div>🧠 Watson…</div>');
  const r=await fetch("/ask-watsonx",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:v})});
  const t=await r.text(); try{ const j=JSON.parse(t); add('<div>AI(Watson): '+esc(j.results?.[0]?.generated_text||j.generated_text||t)+'</div>'); }catch{ add('<div>AI(Watson): '+esc(t)+'</div>'); }
};
</script>
</body></html>`, { headers: { "Content-Type":"text/html; charset=utf-8" } });
    }

    return new Response("Not found", { status: 404 });
  }
};
