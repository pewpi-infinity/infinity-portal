#!/bin/bash
echo "🌟 Starting Infinity Portal..."
python3 server.py
