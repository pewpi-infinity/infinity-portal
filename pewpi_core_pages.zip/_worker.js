// _worker.js — PewPi Core (Chat + Rogers View + Connector Hub)
// Deploy via Cloudflare Pages (Direct Upload). Then in Project Settings:
// - Functions → Durable Objects → Add binding: Class: ChatRoom, Binding name: CHAT_ROOM
// - Secrets: OPENAI_API_KEY, IBM_API_KEY
// - Optional Vars: WX_REGION (us-south), WX_MODEL_ID (ibm/granite-13b-chat-v2), WX_PROJECT
// - Optional Secret: CLIENT_SIGNING_SECRET (enables /mint-client-token and /client-ask)

// Utility: JSON response
const j = (obj, code=200, extra={}) => new Response(JSON.stringify(obj), {
  status: code, headers: { "Content-Type":"application/json", ...extra }
});

// HMAC SHA-256 (for client token minting) — optional
async function hmacSha256Hex(secret, msg) {
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(msg));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, "0")).join("");
}

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);

    // WebSocket endpoint
    if (url.pathname === "/ws") {
      const id = env.CHAT_ROOM.idFromName("global");
      const obj = env.CHAT_ROOM.get(id);
      return obj.fetch(req);
    }

    // ---- OpenAI Chat ----
    if (url.pathname === "/ask-openai" && req.method === "POST") {
      if (!env.OPENAI_API_KEY) return j({ error: "Missing OPENAI_API_KEY" }, 500);
      const { prompt, system, model = "gpt-4o-mini", temperature = 0.7 } = await req.json();
      if (!prompt) return j({ error: "Missing prompt" }, 400);
      const body = {
        model,
        messages: [
          ...(system ? [{ role: "system", content: system }] : []),
          { role: "user", content: prompt }
        ],
        temperature
      };
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
      });
      const text = await r.text();
      return new Response(text, { status: r.status, headers: { "Content-Type": r.headers.get("Content-Type") || "application/json" } });
    }

    // ---- IBM watsonx Chat ----
    if (url.pathname === "/ask-watsonx" && req.method === "POST") {
      if (!env.IBM_API_KEY) return j({ error: "Missing IBM_API_KEY" }, 500);
      const { prompt, system, max_new_tokens = 512 } = await req.json();
      if (!prompt) return j({ error: "Missing prompt" }, 400);

      // 1) Mint IAM token
      const form = new URLSearchParams();
      form.set("grant_type", "urn:ibm:params:oauth:grant-type:apikey");
      form.set("apikey", env.IBM_API_KEY);
      const tok = await fetch("https://iam.cloud.ibm.com/identity/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: form
      });
      if (!tok.ok) return j({ error: "IBM IAM auth failed", status: tok.status }, 502);
      const { access_token } = await tok.json();

      // 2) Inference call
      const region = env.WX_REGION || "us-south";
      const model = env.WX_MODEL_ID || "ibm/granite-13b-chat-v2";
      const base = env.WX_URL || `https://${region}.ml.cloud.ibm.com/ml/v1/text/generation`;
      const input = system ? `${system}\n\nUser: ${prompt}` : prompt;
      const payload = {
        input,
        parameters: {
          decoding_method: "greedy",
          max_new_tokens,
          stop_sequences: ["\nUser:"],
          repetition_penalty: 1.05
        },
        model_id: model,
        project_id: env.WX_PROJECT || undefined
      };

      const r = await fetch(base, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${access_token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const text = await r.text();
      return new Response(text, { status: r.status, headers: { "Content-Type": r.headers.get("Content-Type") || "application/json" } });
    }

    // ---- Duo Ask (Rogers View): query both and return side-by-side ----
    if (url.pathname === "/duo-ask" && req.method === "POST") {
      const { prompt, system } = await req.json();
      if (!prompt) return j({ error: "Missing prompt" }, 400);
      const tasks = [];

      // OpenAI
      if (env.OPENAI_API_KEY) {
        tasks.push((async () => {
          const body = {
            model: "gpt-4o-mini",
            messages: [
              ...(system ? [{ role: "system", content: system }] : []),
              { role: "user", content: prompt }
            ],
            temperature: 0.7
          };
          try {
            const r = await fetch("https://api.openai.com/v1/chat/completions", {
              method: "POST",
              headers: {
                "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
                "Content-Type": "application/json"
              },
              body: JSON.stringify(body)
            });
            const j = await r.json();
            return { provider: "openai", ok: r.ok, status: r.status, text: j.choices?.[0]?.message?.content || JSON.stringify(j) };
          } catch (e) {
            return { provider: "openai", ok: false, status: 500, text: String(e) };
          }
        })());
      }

      // watsonx
      if (env.IBM_API_KEY) {
        tasks.push((async () => {
          try {
            const form = new URLSearchParams();
            form.set("grant_type", "urn:ibm:params:oauth:grant-type:apikey");
            form.set("apikey", env.IBM_API_KEY);
            const tok = await fetch("https://iam.cloud.ibm.com/identity/token", {
              method: "POST",
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              body: form
            });
            if (!tok.ok) throw new Error("IBM IAM auth failed: " + tok.status);
            const { access_token } = await tok.json();

            const region = env.WX_REGION || "us-south";
            const model = env.WX_MODEL_ID || "ibm/granite-13b-chat-v2";
            const base = env.WX_URL || `https://${region}.ml.cloud.ibm.com/ml/v1/text/generation`;
            const input = system ? `${system}\n\nUser: ${prompt}` : prompt;
            const payload = {
              input,
              parameters: { decoding_method: "greedy", max_new_tokens: 512, stop_sequences: ["\nUser:"], repetition_penalty: 1.05 },
              model_id: model,
              project_id: env.WX_PROJECT || undefined
            };
            const r = await fetch(base, {
              method: "POST",
              headers: { "Authorization": `Bearer ${access_token}`, "Content-Type": "application/json" },
              body: JSON.stringify(payload)
            });
            const jr = await r.json();
            const text = jr.results?.[0]?.generated_text || jr.generated_text || JSON.stringify(jr);
            return { provider: "watsonx", ok: r.ok, status: r.status, text };
          } catch (e) {
            return { provider: "watsonx", ok: false, status: 500, text: String(e) };
          }
        })());
      }

      const results = await Promise.all(tasks);
      return j({ prompt, results });
    }

    // ---- Connector Hub: mint short-lived client token (optional) ----
    if (url.pathname === "/mint-client-token" && req.method === "POST") {
      if (!env.CLIENT_SIGNING_SECRET) return j({ error: "Connector Hub disabled (missing CLIENT_SIGNING_SECRET)" }, 403);
      const { ttl = 900 } = await req.json().catch(()=>({}));
      const now = Math.floor(Date.now()/1000);
      const exp = now + Math.max(60, Math.min(3600, ttl));
      const payload = { iat: now, exp, aud: "pewpi", v: 1 };
      const b64 = btoa(JSON.stringify(payload));
      const sig = await hmacSha256Hex(env.CLIENT_SIGNING_SECRET, b64);
      return j({ token: `${b64}.${sig}`, exp });
    }

    // ---- Connector Hub: client-ask using minted token (optional) ----
    if (url.pathname === "/client-ask" && req.method === "POST") {
      if (!env.CLIENT_SIGNING_SECRET) return j({ error: "Connector Hub disabled" }, 403);
      const auth = req.headers.get("Authorization") || "";
      const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
      if (!token) return j({ error: "Missing Bearer token" }, 401);
      const [b64, sig] = token.split(".");
      if (!b64 || !sig) return j({ error: "Bad token format" }, 401);
      const expect = await hmacSha256Hex(env.CLIENT_SIGNING_SECRET, b64);
      if (expect !== sig) return j({ error: "Bad signature" }, 401);
      const payload = JSON.parse(atob(b64));
      const now = Math.floor(Date.now()/1000);
      if (payload.exp < now) return j({ error: "Token expired" }, 401);

      const { prompt, provider = "openai" } = await req.json();
      if (!prompt) return j({ error: "Missing prompt" }, 400);

      if (provider === "watsonx") {
        const form = new URLSearchParams();
        form.set("grant_type", "urn:ibm:params:oauth:grant-type:apikey");
        form.set("apikey", env.IBM_API_KEY);
        const tok = await fetch("https://iam.cloud.ibm.com/identity/token", {
          method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form
        });
        if (!tok.ok) return j({ error: "IAM failed", status: tok.status }, 502);
        const { access_token } = await tok.json();

        const region = env.WX_REGION || "us-south";
        const model = env.WX_MODEL_ID || "ibm/granite-13b-chat-v2";
        const base = env.WX_URL || `https://${region}.ml.cloud.ibm.com/ml/v1/text/generation`;
        const payload2 = {
          input: prompt,
          parameters: { decoding_method: "greedy", max_new_tokens: 256 },
          model_id: model,
          project_id: env.WX_PROJECT || undefined
        };
        const r = await fetch(base, {
          method: "POST",
          headers: { "Authorization": `Bearer ${access_token}`, "Content-Type": "application/json" },
          body: JSON.stringify(payload2)
        });
        const jr = await r.json();
        const text = jr.results?.[0]?.generated_text || jr.generated_text || JSON.stringify(jr);
        return j({ provider: "watsonx", text });
      } else {
        const body = { model: "gpt-4o-mini", messages: [{ role: "user", content: prompt }], temperature: 0.7 };
        const r = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: { "Authorization": `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        const jr = await r.json();
        const text = jr.choices?.[0]?.message?.content || JSON.stringify(jr);
        return j({ provider: "openai", text });
      }
    }

    // ---- Frontend Dashboard (no frameworks) ----
    if (url.pathname === "/") {
      return new Response(`<!doctype html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PewPi Core — Chat • Rogers View • Connector Hub</title>
<style>
*{box-sizing:border-box} body{font:16px system-ui;margin:0;background:#0b0d10;color:#e6e9ef}
.header{padding:14px 16px;border-bottom:1px solid #222;display:flex;justify-content:space-between;align-items:center}
.brand{font-weight:700} .tabs{display:flex;gap:8px}
.tab{padding:8px 12px;border:1px solid #2a2f3a;border-radius:10px;background:#121821;cursor:pointer}
.tab.active{background:#1a2330}
.section{padding:16px} .row{display:flex;gap:8px;margin-top:10px}
input,button,textarea{font:inherit} input,textarea{background:#0f1319;color:#e6e9ef;border:1px solid #2a2f3a;border-radius:10px;padding:10px}
button{background:#18202a;color:#e6e9ef;border:1px solid #2a2f3a;border-radius:10px;padding:10px 14px;cursor:pointer}
button:active{transform:scale(0.98)}
.card{border:1px solid #2a2f3a;border-radius:12px;padding:12px;background:#0f1319}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
#log,#duoLog{height:46vh;overflow:auto}
small.mono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;opacity:.8}
</style></head>
<body>
<div class="header">
  <div class="brand">⚡ PewPi Core</div>
  <div class="tabs">
    <div class="tab active" data-tab="chat">Chat</div>
    <div class="tab" data-tab="rogers">Rogers View</div>
    <div class="tab" data-tab="hub">Connector Hub</div>
  </div>
</div>

<div id="chat" class="section">
  <div class="card" id="log"></div>
  <div class="row">
    <input id="msg" placeholder="Type message…">
    <button id="send">Send</button>
    <button id="askO">Ask OpenAI</button>
    <button id="askW">Ask Watson</button>
  </div>
</div>

<div id="rogers" class="section" style="display:none">
  <div class="row">
    <input id="duoPrompt" placeholder="Ask both providers…">
    <button id="duoAsk">Duo Ask</button>
  </div>
  <div class="grid" style="margin-top:12px">
    <div class="card"><strong>OpenAI</strong><div id="duoA"></div></div>
    <div class="card"><strong>Watsonx</strong><div id="duoW"></div></div>
  </div>
  <div class="card" style="margin-top:12px"><strong>Timeline</strong><div id="duoLog"></div></div>
</div>

<div id="hub" class="section" style="display:none">
  <div class="card">
    <p><strong>Mint short-lived client token</strong> (optional). Lets your site call <code>/client-ask</code> without exposing provider keys.</p>
    <div class="row">
      <input id="ttl" type="number" value="900" min="60" max="3600" style="max-width:160px">
      <button id="mint">Mint Token</button>
    </div>
    <p><small class="mono" id="tokOut"></small></p>
    <hr style="border-color:#222">
    <p><strong>Try client-ask</strong></p>
    <div class="row">
      <input id="cPrompt" placeholder="Prompt">
      <select id="prov"><option value="openai">openai</option><option value="watsonx">watsonx</option></select>
      <button id="cAsk">Call</button>
    </div>
    <div class="card" style="margin-top:10px"><div id="cOut"></div></div>
  </div>
</div>

<script>
// Tabs
document.querySelectorAll('.tab').forEach(t => t.onclick = () => {
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  t.classList.add('active');
  const tab = t.dataset.tab;
  ["chat","rogers","hub"].forEach(id => document.getElementById(id).style.display = (id===tab?"block":"none"));
});

// Utilities
const log = document.getElementById('log');
const duoLog = document.getElementById('duoLog');
const duoA = document.getElementById('duoA');
const duoW = document.getElementById('duoW');
function add(node, html) { node.insertAdjacentHTML('beforeend', html); node.scrollTop = node.scrollHeight; }
function esc(s){return s.replace(/[&<>"]/g,m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[m]))}

// WebSocket Chat
const proto = location.protocol === "https:" ? "wss:" : "ws:";
const ws = new WebSocket(proto + "//" + location.host + "/ws");
ws.onopen = ()=> add(log, '<div class="sys">🔌 connected</div>');
ws.onclose = ()=> add(log, '<div class="sys">🔌 disconnected</div>');
ws.onmessage = e => add(log, '<div>' + esc(e.data) + '</div>');

document.getElementById('send').onclick = ()=>{
  const i = document.getElementById('msg');
  const v = i.value.trim();
  if(!v) return;
  ws.send(v);
  i.value="";
};
document.getElementById('msg').addEventListener('keydown', e => { if(e.key==="Enter") document.getElementById('send').click(); });

// Ask buttons
document.getElementById('askO').onclick = async ()=>{
  const v = document.getElementById('msg').value.trim(); if(!v) return;
  add(log, '<div class="sys">🧠 OpenAI…</div>');
  const r = await fetch("/ask-openai", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ prompt: v }) });
  const t = await r.text();
  try{ const j = JSON.parse(t); const out = j.choices?.[0]?.message?.content || t; ws.send("AI(OpenAI): " + out); }catch{ ws.send("AI(OpenAI): " + t); }
};
document.getElementById('askW').onclick = async ()=>{
  const v = document.getElementById('msg').value.trim(); if(!v) return;
  add(log, '<div class="sys">🧠 Watson…</div>');
  const r = await fetch("/ask-watsonx", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ prompt: v }) });
  const t = await r.text();
  try{ const j = JSON.parse(t); const out = j.results?.[0]?.generated_text || j.generated_text || t; ws.send("AI(Watson): " + out); }catch{ ws.send("AI(Watson): " + t); }
};

// Rogers View (duo)
document.getElementById('duoAsk').onclick = async ()=>{
  const v = document.getElementById('duoPrompt').value.trim(); if(!v) return;
  add(duoLog, '<div class="sys">🧪 asking both…</div>');
  duoA.textContent = ""; duoW.textContent = "";
  const r = await fetch("/duo-ask", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ prompt: v }) });
  const j = await r.json();
  const items = j.results || [];
  for (const it of items) {
    if (it.provider === "openai") duoA.textContent = it.text;
    if (it.provider === "watsonx") duoW.textContent = it.text;
    add(duoLog, '<div><b>'+esc(it.provider)+'</b>: '+esc(it.text)+'</div>');
  }
};

// Connector Hub
let clientToken = "";
document.getElementById('mint').onclick = async ()=>{
  const ttl = parseInt(document.getElementById('ttl').value || "900", 10);
  const r = await fetch("/mint-client-token", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ ttl }) });
  const j = await r.json();
  if (j.token) {
    clientToken = j.token;
    document.getElementById('tokOut').textContent = clientToken;
  } else {
    document.getElementById('tokOut').textContent = (j.error || 'Mint failed');
  }
};
document.getElementById('cAsk').onclick = async ()=>{
  const v = document.getElementById('cPrompt').value.trim(); if(!v) return;
  const prov = document.getElementById('prov').value;
  const r = await fetch("/client-ask", { method:"POST", headers:{ "Content-Type":"application/json", "Authorization": "Bearer " + clientToken }, body: JSON.stringify({ prompt: v, provider: prov }) });
  const j = await r.json();
  document.getElementById('cOut').textContent = JSON.stringify(j, null, 2);
};
</script>
</body></html>`, { headers: { "Content-Type":"text/html; charset=utf-8" } });
    }

    return new Response("Not found", { status: 404 });
  }
};

// Durable Object for pub chat
export class ChatRoom {
  constructor(state, env) { this.state = state; this.env = env; this.sessions = new Set(); }
  async fetch(req) {
    if (req.headers.get("Upgrade") !== "websocket") return new Response("Expected WebSocket", { status: 426 });
    const pair = new WebSocketPair(); const [client, server] = Object.values(pair);
    server.accept();
    this.sessions.add(server);
    try { server.send("👋 welcome to PewPi"); } catch {}
    server.addEventListener("message", (evt) => {
      const msg = String(evt.data || "").slice(0, 4000);
      for (const ws of this.sessions) { try { ws.send(msg); } catch {} }
    });
    const cleanup = ()=> this.sessions.delete(server);
    server.addEventListener("close", cleanup);
    server.addEventListener("error", cleanup);
    return new Response(null, { status: 101, webSocket: client });
  }
}
