
Infinity Uploader — Deploy Bundle
--------------------------------

Files included:
- index.html        : Main launcher page with draggable app-icons and uploader panel.
- app.js            : JavaScript for dragging, uploader preview, and layout persistence.
- style.css         : Minimal styles.
- pages/            : Example pages for icons (sample-page-1.html, sample-page-2.html).
- deploy.sh         : Quick local test server (run on your device to preview).
- infinity_uploader_deploy.zip : (This zip file itself is the deploy bundle you just downloaded.)

How to use:
1) Unzip the bundle into your web host root (e.g., /var/www/html or the 'public' folder on your static host).
2) Ensure the file 'infinity_uploader_deploy.zip' (the package) is present next to index.html if you want the "Download Deploy ZIP" button to work as-is.
3) Open index.html in a browser. Drag icons to arrange them like phone apps. Double-click an icon to open its linked page.
4) To serve locally for testing on a Linux/Android device with Python installed:
   chmod +x deploy.sh
   ./deploy.sh
   Then open http://localhost:8080 in your browser.
5) To add your own pages: create files under the pages/ directory and update the 'data-target' attribute on an icon in index.html.
6) If you want icons styled as app buttons and movable on a phone screen, this UI persists layout in the browser via localStorage.

Quick deploy tips:
- Upload the unzipped folder to your hosting provider (FTP, SFTP, or drag-and-drop on static hosts).
- If using GitHub Pages, push the folder contents to the gh-pages branch or to the repository root and enable Pages.
- If using Vercel/Netlify, point the project to this folder and deploy.

Notes:
- This is a static site. The uploader functionality stores previews locally in your browser only; no server upload endpoint is included. If you want server-side uploads, I can add a simple Node/PHP/Python endpoint.
- The "Download Deploy ZIP" button downloads the prebuilt bundle 'infinity_uploader_deploy.zip' if present on the host. You can replace that file with any package you want users to download.

If you want I can also:
- Add a server-side upload endpoint (Python Flask snippet or Node.js express) so files are actually uploaded to your server.
- Add client-side creation of custom deploy zips from files you choose (requires JSZip, I can include it).
- Make icons editable (change label/icon) and allow exporting the layout as JSON for remote sync.

