// Simple draggable icons, persistent positions in localStorage, uploader preview, and ZIP download of site package (server-side static files provided by host).
(function(){
  // Utilities
  function $(s){return document.querySelector(s)}
  function $all(s){return document.querySelectorAll(s)}

  // Draggable app icons
  const dock = $('#dock');
  const icons = $all('.app-icon');
  const STORAGE_KEY = 'infinity_icon_layout_v1';

  // Load positions
  function loadLayout(){
    try{
      const raw = localStorage.getItem(STORAGE_KEY);
      if(!raw) return;
      const layout = JSON.parse(raw);
      icons.forEach(icon=>{
        const id = icon.id;
        if(layout[id]){
          icon.style.position = 'absolute';
          icon.style.left = layout[id].left;
          icon.style.top = layout[id].top;
        } else {
          icon.style.position = '';
          icon.style.left = '';
          icon.style.top = '';
        }
      });
    }catch(e){console.warn(e)}
  }

  function saveLayout(){
    const layout = {};
    icons.forEach(icon=>{
      if(icon.style.position === 'absolute'){
        layout[icon.id] = { left: icon.style.left, top: icon.style.top };
      }
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(layout));
  }

  // make draggable
  icons.forEach(icon => {
    let dragging = false, startX=0,startY=0, origLeft=0, origTop=0;
    icon.addEventListener('mousedown', (ev)=>{
      dragging = true;
      icon.style.cursor='grabbing';
      startX = ev.clientX; startY = ev.clientY;
      const rect = icon.getBoundingClientRect();
      origLeft = rect.left; origTop = rect.top;
      icon.style.position='absolute';
      icon.style.zIndex = 1000;
      document.body.style.userSelect = 'none';
    });
    window.addEventListener('mousemove', (ev)=>{
      if(!dragging) return;
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      icon.style.left = (origLeft + dx) + 'px';
      icon.style.top = (origTop + dy) + 'px';
    });
    window.addEventListener('mouseup',(ev)=>{
      if(!dragging) return;
      dragging=false;
      icon.style.cursor='grab';
      document.body.style.userSelect = '';
      icon.style.zIndex = '';
      saveLayout();
    });

    // click opens target if present
    icon.addEventListener('dblclick', ()=>{
      const target = icon.dataset.target;
      if(target) window.open(target, '_blank');
      if(icon.id === 'uploader-app'){
        // focus uploader panel
        document.getElementById('file-input').scrollIntoView({behavior:'smooth'});
      }
    });
  });

  // Uploader preview (keeps files client-side only)
  const fileInput = $('#file-input');
  const previews = $('#previews');
  let stagedFiles = []; // {name, dataUrl, type}

  function addPreview(name, dataUrl, type){
    const div = document.createElement('div');
    div.className = 'preview-item';
    div.innerHTML = '<img src="'+dataUrl+'"><div><strong>'+name+'</strong><div style="font-size:12px;color:#666">'+type+'</div></div>';
    previews.appendChild(div);
  }

  fileInput.addEventListener('change', async (ev)=>{
    previews.innerHTML = '';
    stagedFiles = [];
    for(const f of ev.target.files){
      try{
        const reader = new FileReader();
        const p = await new Promise((res, rej)=>{
          reader.onload = ()=>res(reader.result);
          reader.onerror = rej;
          reader.readAsDataURL(f);
        });
        stagedFiles.push({name:f.name, dataUrl:p, type:f.type || 'file'});
        addPreview(f.name, p, f.type || 'file');
      }catch(e){console.warn('read err', e)}
    }
  });

  // Download prebuilt ZIP that contains this site (server-provided). We'll trigger direct download of the ZIP that is packaged with this deploy bundle.
  $('#create-download').addEventListener('click', ()=>{
    // The server-side bundle 'infinity_uploader_deploy.zip' should be placed next to index.html by the host.
    const zurl = 'infinity_uploader_deploy.zip';
    // Attempt to download - if host serves it, browser will start the download.
    const a = document.createElement('a');
    a.href = zurl;
    a.download = 'infinity_uploader_deploy.zip';
    document.body.appendChild(a);
    a.click();
    a.remove();
  });

  $('#reset-layout').addEventListener('click', ()=>{
    localStorage.removeItem(STORAGE_KEY);
    icons.forEach(ic=>{ ic.style.position=''; ic.style.left=''; ic.style.top=''; });
  });

  // initial load
  loadLayout();

  // Accessibility: allow Enter to open on focused icon
  icons.forEach(icon=>{
    icon.addEventListener('keydown', (ev)=>{
      if(ev.key === 'Enter') icon.dispatchEvent(new Event('dblclick'));
    });
  });

})();
