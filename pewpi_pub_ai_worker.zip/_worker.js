// _worker.js — PewPi pub chat + OpenAI Ask (Pages Direct Upload)
// Deploy via Cloudflare Pages (Direct Upload). Then in Project Settings:
// - Functions → Durable Objects → Add binding: Class: ChatRoom, Binding name: CHAT_ROOM
// - Environment Variables → Add secret: OPENAI_API_KEY = your OpenAI key (sk-...)
// No other dependencies required.

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);

    // WebSocket endpoint for pub chat
    if (url.pathname === "/ws") {
      const id = env.CHAT_ROOM.idFromName("global");
      const obj = env.CHAT_ROOM.get(id);
      return obj.fetch(req);
    }

    // OpenAI chat endpoint (no streaming; easy to test)
    if (url.pathname === "/ask-openai" && req.method === "POST") {
      if (!env.OPENAI_API_KEY) {
        return new Response(JSON.stringify({error:"Missing OPENAI_API_KEY"}), {status:500});
      }
      const { prompt, system } = await req.json();
      if (!prompt) return new Response("Missing prompt", { status: 400 });

      const body = {
        model: "gpt-4o-mini",
        messages: [
          ...(system ? [{role:"system", content: system}] : []),
          {role:"user", content: prompt}
        ],
        temperature: 0.7
      };

      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
      });

      const text = await r.text();
      return new Response(text, {
        status: r.status,
        headers: {"Content-Type": r.headers.get("Content-Type") || "application/json"}
      });
    }

    // Minimal HTML client
    if (url.pathname === "/") {
      return new Response(`<!doctype html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PewPi Pub Chat + AI</title>
<style>
  body{font:16px system-ui;margin:20px;background:#0b0d10;color:#e6e9ef}
  h2{margin:0 0 10px}
  #log{border:1px solid #2a2f3a;background:#0f1319;height:52vh;overflow:auto;padding:10px;border-radius:12px}
  #row{display:flex;gap:8px;margin-top:12px}
  #row input{flex:1;padding:10px;border-radius:10px;border:1px solid #2a2f3a;background:#0f1319;color:#e6e9ef}
  #row button{padding:10px 14px;border-radius:10px;border:1px solid #2a2f3a;background:#18202a;color:#e6e9ef;cursor:pointer}
  #row button:active{transform:scale(0.98)}
  .sys{opacity:.7}
</style></head>
<body>
<h2>⚡ PewPi Pub Chat + AI</h2>
<div id="log"></div>
<div id="row">
  <input id="msg" placeholder="Type message…"/>
  <button id="send">Send</button>
  <button id="ask">Ask AI</button>
</div>
<script>
const log = document.getElementById('log');
function add(html){ log.insertAdjacentHTML('beforeend', html); log.scrollTop = log.scrollHeight; }
function esc(s){return s.replace(/[&<>"]/g,m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;" }[m]))}

const proto = location.protocol === "https:" ? "wss:" : "ws:";
const ws = new WebSocket(proto + "//" + location.host + "/ws");
ws.onopen = ()=> add('<div class="sys">🔌 connected</div>');
ws.onclose = ()=> add('<div class="sys">🔌 disconnected</div>');
ws.onmessage = e => add('<div>' + esc(e.data) + '</div>');

document.getElementById('send').onclick = ()=>{
  const i = document.getElementById('msg');
  const v = i.value.trim();
  if(!v) return;
  ws.send(v);
  i.value = "";
};
document.getElementById('msg').addEventListener('keydown', e=>{
  if(e.key==="Enter") document.getElementById('send').click();
});

document.getElementById('ask').onclick = async ()=>{
  const i = document.getElementById('msg');
  const v = i.value.trim();
  if(!v) return;
  add('<div class="sys">🧠 Asking OpenAI…</div>');
  try{
    const r = await fetch("/ask-openai", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({prompt: v})
    });
    const t = await r.text();
    try{
      const j = JSON.parse(t);
      const out = j.choices?.[0]?.message?.content || t;
      ws.send("AI: " + out);
    } catch{
      ws.send("AI: " + t);
    }
  }catch(err){
    ws.send("AI error");
  }
};
</script>
</body></html>`, { headers: { "Content-Type": "text/html; charset=utf-8" } });
    }

    return new Response("Not found", { status: 404 });
  }
};

// Durable Object that broadcasts messages to all connected clients.
export class ChatRoom {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.sessions = new Set();
  }
  async fetch(req) {
    if (req.headers.get("Upgrade") !== "websocket") {
      return new Response("Expected WebSocket", { status: 426 });
    }
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();

    // Join room
    this.sessions.add(server);
    try { server.send("👋 welcome to PewPi"); } catch {}

    // Handle incoming
    server.addEventListener("message", (evt) => {
      const msg = String(evt.data || "").slice(0, 2000);
      this.broadcast(msg);
    });

    // Clean up on close or error
    const cleanup = ()=> this.sessions.delete(server);
    server.addEventListener("close", cleanup);
    server.addEventListener("error", cleanup);

    return new Response(null, { status: 101, webSocket: client });
  }
  broadcast(msg) {
    for (const ws of this.sessions) {
      try { ws.send(msg); } catch {}
    }
  }
}
